# 🪪 Proyecto: SmartPrice
**Materia:** Fundamentos de Ingeniería de Software  
**Entrega 2 — Octubre 2025**  
**Equipo 2**

## 👥 Roles Scrum
| Rol | Integrante | Responsabilidad |
|------|-------------|----------------|
| **Scrum Master** | **Jhoana Pech** | Coordinar el equipo, planificar los sprints, organizar reuniones y revisar entregas. |
| **Developer Team** | Bianca Ramos | Análisis y documentación de requerimientos. |
| **Developer Team** | Ana Angulo | Diseño y estructura de la interfaz. |
| **Developer Team** | Alejandra Angular | Desarrollo de funcionalidades principales. |
| **Developer Team** | Kevin Morales | Revisión técnica y control de calidad. |
| **Developer Team** | Emilio Arellano | Integración de componentes y pruebas. |
| **Developer Team** | José Correa | Soporte técnico y documentación de código. |

## 🚀 Evolución del Producto
Durante esta segunda entrega se implementaron los siguientes avances:
- Refinamiento del módulo principal de comparación de precios.
- Rediseño visual del prototipo con una navegación más intuitiva.
- Ajuste de los requerimientos funcionales conforme a los comentarios del cliente.
- Incorporación de una validación de interfaz con simulación de tareas.

## 🧩 Evolución de Requisitos
Se reorganizó el conjunto de requerimientos funcionales y no funcionales.  
Se agregaron historias de usuario con criterios de aceptación y un diagrama de casos de uso.

## 🖌️ Diseño de Interfaces
El equipo creó un conjunto de prototipos (actualmente en proceso de herramienta).  
Cada interfaz fue evaluada conforme a los requerimientos establecidos y ajustada tras recibir comentarios del cliente.

## ⚙️ Proceso de Desarrollo (Scrum)
El proyecto trabaja con sprints semanales bajo la metodología Scrum.  
Cada sprint cuenta con planeación, reuniones *Weekly Stand Up* y evidencias.

## 📊 Métrica de Contribución Individual
Cada integrante cuenta con una participación del ~14.3%, distribuida de acuerdo a sus tareas y documentación.

## 🧠 Competencias
**Genéricas:** Comunicación efectiva, colaboración en equipo, responsabilidad.  
**Específicas:** Análisis de requerimientos, diseño de interfaces, aplicación de metodologías ágiles.

## 🗂️ Organización del Repositorio
Se creó un branch exclusivo para la entrega 2, con carpetas y documentación ordenada.
