# 📅 Planeación del Sprint 2
**Duración:** Semana del 7 al 13 de octubre  
**Objetivo:** Consolidar el producto con los cambios del cliente y validar los avances del diseño y requerimientos.

| Actividad | Asignado a | Prioridad | Fecha límite | Entregable | Estado |
|------------|-------------|------------|---------------|-------------|---------|
| Análisis de comentarios del cliente | Jhoana Pech | Alta | Lunes 7 | Documento de retroalimentación | En progreso |
| Ordenar el backlog | Bianca Ramos | Alta | Lunes 7 | Backlog actualizado | Completado |
| Actualizar historias de usuario | Ana Angulo | Alta | Martes 8 | Archivo HU.md actualizado | En progreso |
| Diseñar prototipo actualizado | Alejandra Angular | Media | Miércoles 9 | Carpeta de diseño | Pendiente |
| Simulación de tarea en prototipo | Kevin Morales | Media | Jueves 10 | Video corto de validación | Pendiente |
| Documentar reunión Weekly Stand Up | Jhoana Pech | Alta | Viernes 11 | Archivo Weekly_StandUp.md | En progreso |
| Evidencias Sprint 2 | Emilio Arellano, José Correa | Alta | Domingo 13 | Capturas y commits | Pendiente |
