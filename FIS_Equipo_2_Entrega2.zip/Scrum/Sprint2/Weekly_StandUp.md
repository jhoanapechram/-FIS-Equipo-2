# 🧩 Weekly Stand Up - Sprint 2
**Objetivo:** Compartir el avance de cada integrante y resolver bloqueos.

| Integrante | Avance realizado | Próximos pasos | Dificultades |
|-------------|------------------|----------------|---------------|
| Jhoana Pech | Coordinación del sprint y revisión de backlog | Validar entregas | Falta de tiempo |
| Bianca Ramos | Actualización de requerimientos | Documentar cambios | Ninguna |
| Ana Angulo | Inicio de rediseño de interfaz | Terminar prototipo | Dudas de herramienta |
| Alejandra Angular | Revisión del flujo de usuario | Simulación del proceso | Ninguna |
| Kevin Morales | Apoyo en pruebas | Revisar funcionalidad | Ninguna |
| Emilio Arellano | Capturas y registro de avances | Subir evidencias | Ninguna |
| José Correa | Soporte de documentación | Subir commits | Ninguna |
